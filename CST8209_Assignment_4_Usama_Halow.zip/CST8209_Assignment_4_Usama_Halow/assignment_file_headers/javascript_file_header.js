/*
 * Student Name: Usama Halow
 * Student ID: 41110532
 * Course: CST8209 - Web Programming I
 * Semester: 1
 * Assignment: Assignment 3: Calendar of Events – Part 3
 * Date Submitted:  4/5/2024
 */
