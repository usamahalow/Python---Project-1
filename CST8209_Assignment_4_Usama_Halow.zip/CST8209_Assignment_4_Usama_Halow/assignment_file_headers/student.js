function Student(firstName, lastName) {
  this.firstName = firstName,
  this.lastName = lastName,
  this.gpa = null
}

function isNumeric(val) {
  return (typeof val === "number" && !Number.isNaN(val) && Number.isFinite(val));
}

function calculateLetterGrade(percentGrade) {
  
  if (!isNumeric(percentGrade) || percentGrade < 0 || percentGrade > 100) {
    console.log("calculateLetterGrade: " + percentGrade + " is not a valid number.");
    return;
  }
  
  // https://www.algonquincollege.com/policies/files/2022/04/AA14.pdf
  if (percentGrade >= 90) {
    return "A+";
  } else if (percentGrade >= 85) {
    return "A";
  } else if (percentGrade >= 80) {
    return "A-";
  } else if (percentGrade >= 77) {
    return "B+";
  } else if (percentGrade >= 73) {
    return "B";
  } else if (percentGrade >= 70) {
    return "B-";
  } else if (percentGrade >= 67) {
    return "C+";
  } else if (percentGrade >= 63) {
    return "C";
  } else if (percentGrade >= 60) {
    return "C-";
  } else if (percentGrade >= 57) {
    return "D+";
  } else if (percentGrade >= 53) {
    return "D";
  } else if (percentGrade >= 50) {
    return "D-";
  } else {
    return "F";
  }
}

function calculateGPA(letterGrade) {
  
  switch(letterGrade) {
    case "A+":
      return 4.0;
    case "A":
      return 3.8;
    case "A-":
      return 3.6;
    case "B+":
      return 3.3;
    case "B":
      return 3.0;
    case "B-":
      return 2.7;
    case "C+":
      return 2.3;
    case "C":
      return 2.0;
    case "C-":
      return 1.7;
    case "D+":
      return 1.4;
    case "D":
      return 1.2;
    case "D-":
      return 1.0;
    case "F":
      return 0.0;
    default:
      return;
  }
}

do {
  var firstName = prompt("Enter the student's first name: ");
} while (!firstName);

do {
  var lastName = prompt("Enter the student's last name: ");
} while (!lastName);

const aStudent = new Student(firstName, lastName);

document.getElementById("student-name").innerText = aStudent.firstName + " " + aStudent.lastName;
const gradeTable = document.getElementById("grade-table").getElementsByTagName("tbody")[0];

for (let i = 1; i <= 5; i++) 
{
  let grade, letterGrade, innerHTML = "";
 
  //let tableRow = gradeTable.appendChild("<tr>");
  //let tableRow = document.createElement("tr");
 
  do {
    grade = prompt("Enter percent grade " + i + ": ");
  } while (!grade || !(letterGrade = calculateLetterGrade(+grade)));

  innerHTML += "<td>" + grade + "</td>";
  innerHTML += "<td>" + letterGrade + "</td>";

  if (aStudent.gpa) {
    aStudent.gpa = (aStudent.gpa + calculateGPA(letterGrade))/2;
  } else {
    aStudent.gpa = calculateGPA(letterGrade);
  }
  innerHTML += "<td>" + aStudent.gpa.toFixed(1) + "</td>";
  
  gradeTable.innerHTML += "<tr>" + innerHTML + "</tr>";
  
}
